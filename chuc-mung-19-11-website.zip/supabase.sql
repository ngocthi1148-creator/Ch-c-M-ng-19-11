-- Chạy toàn bộ SQL này trong Supabase > SQL Editor.
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  code text not null unique,
  message text not null,
  created_at timestamptz not null default now()
);
alter table public.messages enable row level security;
-- Không tạo policy public. Chỉ API server dùng service_role key để đọc/ghi.
