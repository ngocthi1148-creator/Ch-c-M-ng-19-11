const crypto=require("crypto");
const {createClient}=require("@supabase/supabase-js");
function db(){return createClient(process.env.SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY,{auth:{persistSession:false}})}
function send(res,status,obj){res.status(status).json(obj)}
function cookie(req,name){const raw=req.headers.cookie||"";const part=raw.split(";").map(x=>x.trim()).find(x=>x.startsWith(name+"="));return part?decodeURIComponent(part.slice(name.length+1)):""}
function sign(value){return crypto.createHmac("sha256",process.env.SESSION_SECRET).update(value).digest("hex")}
function setSession(res){const exp=Date.now()+8*60*60*1000;const payload=String(exp);const token=payload+"."+sign(payload);res.setHeader("Set-Cookie",`admin_session=${encodeURIComponent(token)}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800`)}
function clearSession(res){res.setHeader("Set-Cookie","admin_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0")}
function isAdmin(req){const t=cookie(req,"admin_session").split(".");if(t.length!==2)return false;const expected=sign(t[0]);const a=Buffer.from(t[1]),b=Buffer.from(expected);return a.length===b.length&&crypto.timingSafeEqual(a,b)&&Number(t[0])>Date.now()}
function method(req,res,allowed){if(!allowed.includes(req.method)){res.setHeader("Allow",allowed.join(", "));send(res,405,{error:"Method not allowed"});return false}return true}
module.exports={db,send,setSession,clearSession,isAdmin,method};