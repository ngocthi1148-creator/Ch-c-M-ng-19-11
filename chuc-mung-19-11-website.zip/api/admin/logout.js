const {send,clearSession,method}=require("../_lib");
module.exports=async(req,res)=>{if(!method(req,res,["POST"]))return;clearSession(res);send(res,200,{ok:true})};