# Chúc Mừng 19/11 – website lời nhắn cá nhân

Bản starter triển khai online: 1 QR chung → người nhận nhập mã riêng → chỉ hiện lời nhắn khớp mã. Có trang quản trị thêm/sửa/xóa cho khoảng 50 người.

## Cần chuẩn bị
- Tài khoản Supabase để lưu dữ liệu trực tuyến dùng chung.
- Tài khoản Vercel để triển khai website.
- Không gửi mật khẩu quản trị hoặc Supabase service-role key cho người nhận.

## 1. Tạo cơ sở dữ liệu
1. Tạo project mới tại https://supabase.com/
2. Mở SQL Editor, chạy toàn bộ nội dung `supabase.sql`.
3. Vào Project Settings → API, lấy Project URL và `service_role` key. Giữ kín key này.

## 2. Đưa mã nguồn lên GitHub
1. Giải nén ZIP và đưa toàn bộ thư mục lên một repository GitHub riêng tư.
2. Không đưa file `.env` hoặc khóa bí mật vào GitHub.

## 3. Triển khai Vercel
1. Đăng nhập https://vercel.com/ và chọn Add New → Project, import repository.
2. Thêm Environment Variables:
   - `SUPABASE_URL`: Project URL từ Supabase
   - `SUPABASE_SERVICE_ROLE_KEY`: service_role key
   - `ADMIN_PASSWORD`: mật khẩu quản trị dài, khó đoán và chỉ bạn biết
   - `SESSION_SECRET`: chuỗi ngẫu nhiên dài tối thiểu 32 ký tự
3. Deploy. Sau khi deploy, website có URL dạng `https://ten-du-an.vercel.app`.

## 4. Sử dụng
- Mở `https://TEN-MIEN-CUA-BAN.vercel.app/admin.html`.
- Đăng nhập bằng `ADMIN_PASSWORD`.
- Thêm tên, mã số riêng và lời nhắn cho từng người (có thể thêm khoảng 50 bản ghi).
- QR chung xuất hiện trong trang quản trị. Tải QR và chia sẻ/in ra.
- Người nhận quét QR, nhập mã riêng trên trang chủ.

## Bảo mật và lưu ý
- Dữ liệu lưu trong Supabase, nên tất cả người nhận nhìn thấy cùng một hệ thống dữ liệu.
- API công khai chỉ trả về tên và lời nhắn khớp chính xác với mã được nhập; không có API công khai liệt kê toàn bộ người nhận.
- Service-role key chỉ nằm ở biến môi trường server của Vercel, tuyệt đối không đưa vào frontend.
- Dùng mã khó đoán thay vì số thứ tự đơn giản; không dùng thông tin nhạy cảm trong lời nhắn.
- Cookie quản trị có thời hạn 8 giờ. Đăng xuất khi dùng xong.
- Trước khi phát QR cho mọi người, hãy thử bằng một mã mẫu và kiểm tra cả điện thoại.
- Đây là bộ mã nguồn cần bạn tự cấu hình và triển khai; chưa phải website đã được publish. Cần cấu hình Supabase/Vercel và tên miền công khai để QR hoạt động với tất cả mọi người.
